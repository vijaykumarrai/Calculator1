This repository contains code for a calculator which will take input as mentioned below and returns the result.

############################################
 Please enter input in the following format : 
 arg1 
 arg2 
 operator
 operators supported are + - \ * 

 press c to clear the result 
 press q to exit.

 results of previous computation will be assigned to argument1.

 press c to start with fresh computation. c will reset all the previous values.
############################################

This Calculator takes input from Scanner, one input at a time. Hit enter after entering each value and operator. Enter the 2 argument values followed by the operator for the operation to be performed.

> 5 
5
> 8
8
> +
13

The result of previous computation will be assigned to the argument1. So to continue the calculation enter the next argument value and then the operator.

> -3
-3.0
> -2
-2.0
> *
6.0
> 5
5.0
> +
11.0

To clear the previous computation result and to do the fresh calculation Enter c. then you can enter argument1, argument2 and then operator.

To close the execution Enter q.






The codebase has 2 classes.

1)	Calculator.java

This has the main method which is the entry point to the application.
This inturn calls calculate() method which reads the values from the scanner, validates and performs the computation and displays the result for the input provided.

2)	Util.java

This has helper methods for validating the inputs, identfying the operator and clear and exit commands input.

