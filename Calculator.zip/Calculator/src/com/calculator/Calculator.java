package com.calculator;

import java.util.Scanner;

public class Calculator {
	public static final float DEFAULT = -999999999999999999f;
	float result;
	float input1;
	float input2;

	/**
	 * Constructor
	 */
	public Calculator() {
		result = DEFAULT;
		input1 = DEFAULT;
		input2 = DEFAULT;
	}

	/**
	 * entry point to the application
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Calculator c = new Calculator();
		System.out.println("############################################\n"
				+ " Please enter input in the following format : \n" + " arg1 \n arg2 \n operator\n"
				+ " operators supported are + - \\ * \n\n" + " press c to clear the result \n" + " press q to exit.\n\n"
				+ " results of previous computation will be assigned to argument1.\n\n"
				+ " press c to start with fresh computation. c will reset all the previous values.\n"
				+ "############################################\n");

		c.calculate();
	}

	/**
	 * this method takes input and validates the input check if exit or clear call
	 * computeResult() method to do the required calculation
	 */
	private void calculate() {
		while (true) {
			Scanner in = new Scanner(System.in);
			String input = in.nextLine().trim();

			/* check input is valid */
			if (!Util.validate(input)) {
				System.out.println("Please re-enter the input in correct format.");
				continue;
			}

			try {
				/* check if exit requested */
				if (Util.isExit(input)) {
					System.out.println(result);
					return;
				}
				/* check if clear the result */
				if (Util.isClear(input)) {
					System.out.println("Clearing the previous result.");
					reset();
					continue;
				}

				computeResult(input);

			} catch (Exception e) {
				System.out.println("Please re-enter the input in correct format.. Resetting the calculator.");
				reset();
				continue;
			}
		}
	}

	/**
	 * compute and display the result
	 * 
	 * @param input
	 */
	private void computeResult(String input) {
		if (Util.isOperator(input)) {
			if (input1 != DEFAULT && input2 != DEFAULT) {
				result = Util.calculate(input1, input2, input);
				input1 = result;
				input2 = DEFAULT;
				System.out.println(result);
			} else {
				System.out.println("input1 or input 2 are null. Please enter both the inputs before operation");
			}
		} else {
			if (input1 != DEFAULT && input2 != DEFAULT) {
				System.out.println("Invalid input. Please enter the operation required");
			} else {
				if (input1 == DEFAULT) {
					input1 = Float.valueOf(input);
					System.out.println(input);
				} else if (input1 != DEFAULT && input2 == DEFAULT) {
					input2 = Float.valueOf(input);
					System.out.println(input);
				}
			}
		}
	}

	/**
	 * reset the values
	 */
	private void reset() {
		input1 = DEFAULT;
		input2 = DEFAULT;
		result = DEFAULT;
	}
}