package com.calculator;

public class Util {
	public static final float INIT = -999999999999999999f;

	/**
	 * Validates the input
	 * 
	 * @param input
	 * @return boolean
	 */
	public static boolean validate(String input) {
		return (isExit(input) || isOperator(input) || isFloat(input) || isClear(input));
	}

	/**
	 * Do the calculation based on the operator.
	 * 
	 * @param input1
	 * @param input2
	 * @param operation
	 * @return float
	 */
	public static float calculate(float input1, float input2, String operation) {
		if ("/".equals(operation)) {
			return input1 / input2;
		} else if ("%".equals(operation)) {
			return input1 % input2;
		} else if ("+".equals(operation)) {
			return input1 + input2;
		} else if ("-".equals(operation)) {
			return input1 - input2;
		} else if ("*".equals(operation)) {
			return input1 * input2;
		} else {
			throw new RuntimeException("Please enter correct value");
		}

	}

	/**
	 * Check if exit button pressed.
	 * 
	 * @param name
	 * @return boolean
	 */
	public static boolean isExit(String name) {
		return ("q".equals(name) || "exit".equals(name));
	}

	/**
	 * Check if clear button pressed.
	 * 
	 * @param name
	 * @return boolean
	 */
	public static boolean isClear(String name) {
		if ("c".equals(name)) {
			return true;
		}
		return false;
	}

	/**
	 * Check if the value entered is float.
	 * 
	 * @param s
	 * @return boolean
	 */
	public static boolean isFloat(String s) {
		try {
			float number = Float.valueOf(s);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * Check if the entered value is operator.
	 * 
	 * @param op
	 * @return boolean
	 */
	public static boolean isOperator(String op) {
		if ("/".equals(op) || "%".equals(op) || "+".equals(op) || "-".equals(op) || "*".equals(op)) {
			return true;
		}
		return false;
	}

}
